<?php
/*
Plugin Name: Your Custom Login Page
Plugin URI: None Yet
Description: Allows user to customize their Wordpress login page.
Version: 1.0
Author: Christian Mackler
License: GPLv2 or later
*/



//Load jQuery
add_action( 'login_enqueue_scripts', 'custom_login_enqueue_scripts' );
function custom_login_enqueue_scripts()
{
	wp_enqueue_script('jquery');
}

//Custom login stylesheet
function custom_login_css() {
echo '<link rel="stylesheet" type="text/css" href="' . plugins_url( 'your-custom-login-page/login-styles.css' , dirname(__FILE__) ) . '" > ';
}
add_action('login_head', 'custom_login_css');

//Login logo link
add_filter( 'login_headerurl', 'custom_login_header_url' );
function custom_login_header_url($url) {
return get_site_url();
}

function my_custom_login_logo() {
     echo '<style type="text/css">                                                                   
         h1 a { background-image:url('.get_stylesheet_directory_uri().'/images/logo.png) !important; 
         height: 100px !important; width: 320px !important;}                            
     </style>';
}
add_action('login_head', 'my_custom_login_logo');


//WSI WebSpecialist link
add_action('login_footer', 'custom_footer');
function custom_footer() {
echo '<br />
<div class="wsiLogo">
<p>Website solution provided by:</p>
<a href="http://www.wsiwebspecialist.com"><span></span></a>
</div>';
}

//Login form fade-in effect
add_action( 'login_head', 'ycl_fadein');

function ycl_fadein() {
echo '<script type="text/javascript">// <![CDATA[
jQuery(document).ready(function() { jQuery("#loginform,#nav,#backtoblog").css("display", "none");          jQuery("#loginform,#nav,#backtoblog").fadeIn(1500);     
});
// ]]></script>';
}





?>